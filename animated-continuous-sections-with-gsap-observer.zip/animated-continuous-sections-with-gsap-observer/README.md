# Animated Continuous Sections with GSAP Observer

A Pen created on CodePen.io. Original URL: [https://codepen.io/Shashank-G2/pen/LYqROwR](https://codepen.io/Shashank-G2/pen/LYqROwR).

